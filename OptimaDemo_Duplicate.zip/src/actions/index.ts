import * as axios from 'axios';
const url = 'http://marketdata.websol.barchart.com/getHistory.json?key=3b5d7808c5ced9c41422e1e6158c4939&symbol=IBM&type=daily&startDate=20160528000000';

let loadEmployees = (x:string) => {

  const request = axios.get(url);
  console.log("Action is Initiated");
  return function (dispatch) {
    return request.then((response) => dispatch({type: 'SHOW_EMPLOYEE', payload: response})
    );
  };
}

export default loadEmployees;
