import * as React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as _ from 'lodash';

import loadEmployees from '../actions';

interface Props extends React.Props<MyPage> {
  employees? : Array<any>;
  loadEmployees? : (x:string) => void;
}

interface State {
  myData: any;
}

class MyPage extends React.Component<Props, State>{

  constructor(props){
    super(props);
    this.state = {myData: null};

  }


  public componentWillMount(){
    this.props.loadEmployees("real");
  }

  showresults(items, index){
    return(
      <tr key={index}>
        <td>{items.symbol}</td>
        <td>{items.tradingDay}</td>
        <td>{items.open}</td>
        <td>{items.high}</td>
        <td>{items.low}</td>
        <td>{items.close}</td>
        <td>{items.volume}</td>
      </tr>
    )
  }

  public render(){
    console.log("In Render");
    console.log(this.props.employees);

    if(this.props.employees){
      var result = this.props.employees.map(this.showresults)
    }
    return(<div className="container">

      <h1>Hello World from Tsx</h1>
      <hr />
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Company</th>
            <th>Trading Day</th>
            <th>Open</th>
            <th>High</th>
            <th>Low</th>
            <th>Close</th>
            <th>Volume</th>
          </tr>
        </thead>
        <tbody>
          {result}
        </tbody>
      </table>

    </div>);
  }
}

const mapStatetoProps = (state) =>{
  return {
    employees: state.employees
  }
}

const mapDispatchToProps = (dispatch)=>{
  return bindActionCreators ({loadEmployees}, dispatch);
}

const ContainerMembersPage = connect(mapStatetoProps, mapDispatchToProps)(MyPage);
export default ContainerMembersPage;
