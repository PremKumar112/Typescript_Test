import * as $ from 'jquery';

export default (state : any = null, action) => {
switch (action.type) {
        case 'SHOW_WEATHER':
        let prevList = [];
          if(state!=null){
            prevList  = $.extend([], state.weather);
          }
          console.log("action.payload.data", action.payload.data);
          prevList.push(action.payload.data);
          let updatedList = prevList
          console.log("reducer data", updatedList);
          return $.extend([], state, {weather:updatedList});
          default:
          return state;
        }
  };
