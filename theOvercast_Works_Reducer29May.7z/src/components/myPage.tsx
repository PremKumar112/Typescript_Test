import * as React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import fetchWeather from '../actions';
import { Sparklines, SparklinesLine, SparklinesReferenceLine } from 'react-sparklines';

interface Props extends React.Props<MyPage> {
  employees? : Array<any>;
  fetchWeather? : (city:string) => void;
}

interface State {
  mySearch:string;
}

class MyPage extends React.Component<Props, State>{
    constructor(props){
    super(props);
    this.state = {mySearch: ''};
    this.onInputChange = this.onInputChange.bind(this);
    this.onFormSubmit = this.onFormSubmit.bind(this);
}

onFormSubmit=(event)=>{
  event.preventDefault();
  let city:string = this.state.mySearch;

  this.props.fetchWeather(city);
  this.setState({ mySearch: '' });
}

onInputChange =(event)=>{
  this.setState({ mySearch: event.target.value });
}

displayWeather(cityData, index){
  const temp = cityData.list.map(weath => weath.main.temp);
  const press = cityData.list.map(weath=>weath.main.pressure);
  const humidity = cityData.list.map(weath=>weath.main.humidity);

  return(
  <tr key={index}>
    <td>{cityData.city.name}</td>
    <td>
        <Sparklines data={temp} style={{background: "#00bdcc"}} margin={10} height={40}>
        <SparklinesLine style={{ stroke: "white", fill: "8fc638" }} />
        <SparklinesReferenceLine
          style={{ stroke: 'white', strokeOpacity: .75, strokeDasharray: '2, 2' }} />
        </Sparklines>
    </td>
    <td>
      <Sparklines data={press} style={{background: "#00bdcc"}} margin={10} height={40}>
      <SparklinesLine style={{ stroke: "white", fill: "8fc638" }} />
      <SparklinesReferenceLine
      style={{ stroke: 'white', strokeOpacity: .75, strokeDasharray: '2, 2' }} />
      </Sparklines>
    </td>
    <td>
      <Sparklines data={humidity} style={{background: "#00bdcc"}} margin={10} height={40}>
      <SparklinesLine style={{ stroke: "white", fill: "8fc638" }} />
      <SparklinesReferenceLine
      style={{ stroke: 'white', strokeOpacity: .75, strokeDasharray: '2, 2' }} />
      </Sparklines>
    </td>
  </tr>)
}


  public render(){

      var listWeather:any;
      if(this.props.employees){
        listWeather=this.props.employees.weather.map(this.displayWeather);
      }

      return(<div className="container">
      <div className="row">
      <h1>OverCast</h1>
      <hr />
      <div className="col-md-1 col-lg-1"></div>
      <div className="col-xs-12 col-sm-12 col-md-10 col-lg-10">
      <form onSubmit ={this.onFormSubmit} className="input-group">
        <input
        placeholder="Get Week Forecast of your City"
        className="form-control"
        value={this.state.mySearch}
        onChange={this.onInputChange}/>
        <span className="input-group-btn">
          <button type="submit" className="btn btn-secondary">Submit</button>
        </span>
      </form>
      <hr />
      </div>
      <div className="col-md-1 col-lg-1"></div>
      </div>

      <div className="row">
      <table className="table table-bordered bg-warning">
        <thead>
          <tr>
          <th>City</th>
          <th>Temperature</th>
          <th>Pressure</th>
          <th>Humidity</th>
          </tr>
        </thead>
        <tbody>
          {listWeather}
        </tbody>
      </table>
      </div>

      </div>);
  }
}

const mapStatetoProps = (state) =>{
  return {
    employees: state.employees
  }
}

const mapDispatchToProps = (dispatch)=>{
  return bindActionCreators ({fetchWeather}, dispatch);
}

const MPage = connect(mapStatetoProps, mapDispatchToProps)(MyPage);
export default MPage;
