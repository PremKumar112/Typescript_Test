import * as React from 'react';
import { Store, createStore, applyMiddleware } from 'redux';
import { Provider } from 'react-redux';
import reduxThunk from 'redux-thunk';
import reducers  from '../reducers';
import MyPage from './myPage';

interface Props extends React.Props<App> {
}

let store = createStore(reducers, applyMiddleware(reduxThunk));

export default class App extends React.Component<Props, {}> {
   public render() {
       return (
         <Provider store={store}>
            <div className="container">
              <MyPage />
              </div>
         </Provider>
       );
  }
}
