
export default (state : any = null, action) => {
        switch (action.type) {
          case 'SHOW_EMPLOYEE':
            console.log(action.payload);
            console.log(action.payload);
            return [...action.payload];

            default:
              return state;
        }
};
