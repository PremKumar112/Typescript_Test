import * as $ from 'jquery';

export default (state : any = null, action) => {
switch (action.type) {
        case 'SHOW_WEATHER':
          console.log(action.payload.data.list);          
          return $.extend({},state, {weather: action.payload.data});
          default:
          return state;
        }

  };
