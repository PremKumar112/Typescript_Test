var path = require('path');
var webpack = require('webpack');
///import ExtractTextPlugin from 'extract-text-webpack-plugin'

module.exports = {
    devServer: {
        inline: true,
        contentBase: './dist',
        port: 3000
    },
    devtool: 'cheap-module-eval-source-map',
    entry: './dev/js/index.js',
    module: {
        loaders: [
            {
                test: /\.js$/,
                loaders: ['babel'],
                exclude: /node_modules/
            },
            {
                test: /\.scss/,
                loader: 'style-loader!css-loader!sass-loader'
            }
        ]
    },
    output: {
        path: 'dist',
        filename: 'bundle.js'
    },
    plugins: [
        new webpack.optimize.OccurrenceOrderPlugin(),
        new webpack.DefinePlugin({
          'process.env': {
            NODE_ENV: JSON.stringify('development')
          },
          'dev':{
            URL: 'https://jsonplaceholder.typicode.com/'
          }
        })
        /*new ExtractTextPlugin({
          filename: 'dist/style1.css',
          allChunks: true,
        })*/
    ]
};
