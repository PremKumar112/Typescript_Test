import React, {PropTypes, Component} from 'react';
import Header from '../components/header.js';
import Navigate from '../components/navigation.js';
import FirstSec from '../components/firstSection.js';
import Footer from '../components/footer.js';

export default class App extends Component{
  constructor(props){
    super(props);

    this.state = {
      office: 'Hoodi',
      vehicle: 'Honda'
    }

  }

  componentWillMount(){
    console.log("App Component is mounting");
  }

  componentDidMount(){
    console.log("App Component is Mounted");
  }

  render(){
    return(
      <div className="container">

        <ul>
          {this.props.person.map((item)=>{
            return(<li key={item.email}>Company is: {item.company} and Email is: {item.email}  </li>)
          })}
        </ul>
        <Header />
        <Navigate />
        <FirstSec />
        <Footer />
      </div>);
  }
}

App.defaultProps ={
  person: [{email: 'alpha@face.com', company: 'Facebook'},
  {email: 'john@microsoft.com', company: 'Microsoft.com'}, {email: 'mark@bps.com', company: 'British Petro'}]
}

App.proptypes ={
  name: PropTypes.string,
  location: PropTypes.string
}
