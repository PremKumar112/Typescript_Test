import React, { Component } from 'react';

class Navigate extends Component{
    constructor(props){
      super(props);
    }

    render(){
      return(
        <div className="row">
          <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
      			<nav className="navbar navbar-default">
      				<div className="container-fluid">
      					<ul className="nav navbar-nav">
      						<li className="active"><a href="#">Home</a></li>
      						<li><a href="#">Services</a></li>
      						<li><a href="#">Products</a></li>
      						<li><a href="#">Contact Us</a></li>
      					</ul>
      				</div>
      			</nav>
		  </div>
        </div>
      );
    }

}
export default Navigate;
