import React, { Component } from 'react';

class Footer extends Component{
  constructor(props){
    super(props);
  }

  render(){
    return(
      <div className="row">
      <footer>
        <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-center">
          <center>
			        <p>Copyright &copy;Aricent.com </p>
		      </center>
        </div>
      </footer>
      </div>
    );
  }
}
export default Footer;
