import React, { Component } from 'react';

export default class Header extends Component {

  constructor(props){
    super(props);
  }

  componentWillMount(){
    console.log("Header is Mounting");
  }

  render(){
    return(
      <div className="row">
        <header>
          <div className="headrow">
            <div className="col-xs-12 col-sm-12 col-md-3 col-lg-3 ">
              <div className="headicon">
              <img className="pad-5-px" width="200" src="assets/img/Aricent.png" alt="Logo"/>
              </div>
            </div>
            <div className="col-xs-12 col-sm-12 col-md-4 col-lg-4 text-center">
              <div className="headicon">
              <h1>Aricent</h1>
              </div>
            </div>
            <div className="col-xs-12 col-sm-12 col-md-8 col-lg-3 pull-right">
            <div className="headicon">
            <button type="button" className="btn btn-default btn-md">
              <span className="glyphicon glyphicon-user"></span> User
            </button>
            <button type="button" className="btn btn-default btn-md">
              <span className="glyphicon glyphicon-shopping-cart"></span> Shopping Cart
            </button>
            </div>
          </div>
          </div>
        </header>
    </div>
  );
  }

}
