import React, { Component } from 'react';

class FirstSec extends Component {
  constructor(props){
    super(props);
  }

  render(){
    return(
      <div className="row">
        <section className="sectionFirst">
          <div className="col-md-2 col-lg-2"></div>
          <div className="col-xs-12 col-sm-12 col-md-8 col-lg-8">
			       <div className="input-group">
				         <input type="text" type="search" className="form-control" placeholder="Enter Search Here" autoFocus/>
				             <span className="input-group-btn">
					                <button className="btn btn-default" type="button">Search</button>
				                      </span>
			         </div>
		      </div>
          <div className="col-md-2 col-lg-2"></div>
		  </section>
      </div>
    );
  }
}

export default FirstSec;
