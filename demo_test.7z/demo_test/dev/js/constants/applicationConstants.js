export const APP_CONSTANT = {
  APP: 'app'
};
