let root = 'https://jsonplaceholder.typicode.com/'
///((process.env.NODE_ENV == 'development')?(dev.URL):(prod.URL));

export const SERVICE_URLS = {
  GET_USERS_LIST: root + 'users',
  REMOVE_USER: root + 'users/',
  GET_USER_INFO: root + 'users/',
  SET_USER_INFO: root + 'users/',
};
