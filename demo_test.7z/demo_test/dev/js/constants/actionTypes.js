export const GET_USERS_LIST = 'GET_USERS_LIST'
export const REMOVE_USER = 'REMOVE_USER'
export const GET_USER_INFO= 'GET_USER_INFO'
export const SET_USER_INFO = 'SET_USER_INFO'
