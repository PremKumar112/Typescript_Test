export const ROUTE_PATH_CONSTANT = {
  home: '/home',
  page1: '/page1',
  page2: '/page2',
  userProfile: '/user/(:id)'
};
