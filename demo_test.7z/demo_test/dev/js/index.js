/* react libraries */
import React from 'react';
import {render} from "react-dom";
import {Provider} from 'react-redux';
import { Router, browserHistory } from 'react-router';

/* third-party libraries */
import 'babel-polyfill';

/* store configurations */
import configureStore from './store/index';

/* app constatnts */
import {APP_CONSTANT} from './constants/applicationConstants'

import App from './containers/app';

/* SASS Style Import */
require('./scss/style.scss');

const store = configureStore();

/* render the components based on routes and capture the url history */
render(
    <Provider store={store}>
      <App />
    </Provider>,
    document.getElementById(APP_CONSTANT.APP)
);
