import {SERVICE_URLS} from '../constants/serviceURL';
import * as types from '../constants/actionTypes';

import axios from 'axios';
import _ from 'lodash';

let getUsersList = () =>{
  const url=SERVICE_URLS.GET_USERS_LIST;
  const apiGetUsersListRequest=axios.get(url);

    return(dispatch)=>{
      return apiGetUsersListRequest.then(({data})=>{
          dispatch({type:types.GET_USERS_LIST, apiUserListResult:data});
      }).catch((error)=>{
         throw(error);
      });
   }
}


let removeUser = (id, usersList) =>{
  const url=SERVICE_URLS.REMOVE_USER + id;
  const apiRemoveUserListRequest=axios.delete(url);

    return(dispatch)=>{
      return apiRemoveUserListRequest.then(({})=>{
          let usersAfterRemove = _.reject(usersList, ['id', id]);
          dispatch({type:types.REMOVE_USER, apiUserRemoveResult:usersAfterRemove});
      }).catch((error)=>{
         throw(error);
      });
   }
}

let getUserDetails = (id) =>{
  const url=SERVICE_URLS.GET_USER_INFO + _.toNumber(id);
  const apiGetUserInfoRequest=axios.get(url);

    return(dispatch)=>{
      return apiGetUserInfoRequest.then(({data})=>{
          dispatch({type:types.GET_USER_INFO, apiUserInfoResult:data});
      }).catch((error)=>{
         throw(error);
      });
   }
}


let updateUserInfo = (userInfo, id) =>{
  const url=SERVICE_URLS.SET_USER_INFO + _.toNumber(id);
  const apiSetUserInfoRequest=axios.put(url, userInfo);

    return(dispatch)=>{
      return apiSetUserInfoRequest.then(({data})=>{
          dispatch({type:types.SET_USER_INFO, apiUserInfoResult:userInfo});
      }).catch((error)=>{
         throw(error);
      });
   }
}

export {getUsersList, removeUser, getUserDetails, updateUserInfo};
