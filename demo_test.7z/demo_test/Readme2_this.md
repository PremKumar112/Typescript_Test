In package.json before adding helper

{
  "name": "storeApp",
  "version": "1.0.0",
  "main": "index.js",
  "scripts": {
    "test": "mocha && mocha test",
    "dev": "webpack",
    "start": "webpack-dev-server"
}

When making the ashu index page: we took out the below line from index.js page
of de/js/index.js page and added

<Router history={browserHistory} routes={routes}></Router>
and instead we added <App />
