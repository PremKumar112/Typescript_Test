import React from 'react';
import { mount, shallow, render } from 'enzyme';
import {expect} from 'chai';
import sinon from 'sinon';

import App from '../dev/js/containers/app.js';
import Header from '../dev/js/components/header.js';
import Footer from '../dev/js/components/header.js';
import FirstSection from '../dev/js/components/header.js';
import Navigation from '../dev/js/components/header.js';


describe('Component/App', function(){
  it('App should exist', function(){
    const item= render(<App />);
    expect(item).to.exist;
  });

  it('should Exist', function () {
    const item = shallow(<App/>);
    expect(item).to.exist;
  });

  it('should have children', function(){
    const wrapper = mount(<App />);
    expect(wrapper.children()).to.have.length(5);
  });

  it('should have an initial office state', function(){
    const wrapper = mount(<App />);
    expect(wrapper.state().office).to.equal('Hoodi');
  });

  it('should have an initial Vehicle state', function(){
    const wrapper = mount(<App />);
    expect(wrapper.state().vehicle).to.equal('Honda');
  });

  it('should have an initial Vehicle state', function(){
    const wrapper = mount(<App />);
    expect(wrapper.setState({office: 'Manyata', vehicle: 'Car'}));
    expect(wrapper.state().vehicle).to.equal('Car');
    expect(wrapper.state().office).to.equal('Manyata');
  });

  it('should have a list of children equal to prop array length', function(){
    const term = [{email: 'alpha@face.com', company: 'Facebook'},
    {email: 'john@microsoft.com', company: 'Microsoft.com'}, {email: 'mark@bps.com', company: 'British Petro'}]

    const wrapper = mount(<App myProp={term}/>);
    expect(wrapper.find('ul').children()).to.have.length(term.length);
  });

  it('should have props for name and location', function(){
    const wrapper = mount(<App name='Prem' location='Kent'/>);
    expect(wrapper.props().name).to.be.defined;
    expect(wrapper.props().location).to.be.defined;
    expect(wrapper.props().name).to.equal('Prem');
    expect(wrapper.props().location).to.equal('Kent');
  })

  it('App should contain a Header Component', function(){
    const wrapper = mount(<App />);
    expect(wrapper.find(Header)).to.have.length(1);
  });

  it('should have an logo image in Header Component', function(){
    const wrapper = mount(<Header />);
    expect(wrapper.find('img')).to.have.length(1);
  });

  it('App should contain a Footer Component', function(){
    const wrapper = mount(<App />);
    expect(wrapper.find(Footer)).to.have.length(1);
  });

  it('App should contain a Navigation Bar Component', function(){
    const wrapper = shallow(<App />);
    expect(wrapper.find(Navigation)).to.have.length(1);
  })

  it("should call componentWillMount Lifecycle method", function(){
    const spys = sinon.spy(App.prototype, 'componentWillMount');
    const wrapper = mount(<App />);
    expect(spys.calledOnce).to.equal(true);
  })

  it("should call componentDidMount Lifecycle method", function(){
    const spys = sinon.spy(App.prototype, 'componentDidMount');
    const wrapper = mount(<App />);
    expect(spys.calledOnce).to.equal(true);
    spys.restore();
  })

});
