First we need to install the dependencies

npm install mocha chai sinon enzyme jsdom@6 react-addons-test-utils babel-register --save-dev

Then we need to create the headless browser
Why do we create a headless browser

putting require('babel-register')();

var jsdom = require('jsdom').jsdom;
var exposedProperties = ['window', 'navigator', 'document'];

//Making an empty document
global.document = jsdom('');

// attaching document to window in default
global.window = document.defaultView;


Object.keys(document.defaultView).forEach((property)=>{
  if (typeof global[property] === 'undefined'){
    exposedProperties.push(property);
    global[property] = document.defaultView[property];
  }
});

// For navigation

global.navigator = {
  userAgent: 'node.js'
};

documentRef = document;

>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

The above is a browser.js and we need to somehow tell our test environment that before you execute my tests, you need to create the document first

So in package.json we do and under script:

"test": "mocha -w test/helpers/browser.js test/*.spec.js",

What this will do is that mocha will first run with the helper and execute the browser.js and create a document for the scope of the test.
This happens everytime we run the npm test

after that it will look for any file inside the test folder with extension .spec.ts

the reason why we want the mocha to load and test the .spec.js file only is because say we have a few util methods in the test folder that
we know are not tests so we do not want the mocha to examine that instead call them as and when required inside our test

>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


We will test-utils
shallow
mount
sinon-spy

>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

We can create a mocha.opts file with below configurations in the test folder

--recursive
--reporter nyan
-- timeout 5000 (In case we are doing an api call and we know that it may take some time for the response to come back)

>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
