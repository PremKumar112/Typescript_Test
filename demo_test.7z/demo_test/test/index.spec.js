import * as React from 'react';
import { renderIntoDocument } from 'react-addons-test-utils';
import App from '../dev/js/containers/app.js';

var chai = require('chai');
var expect = require('chai').expect;
