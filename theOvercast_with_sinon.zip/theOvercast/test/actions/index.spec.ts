declare function require(name:string);

import { expect } from 'chai';
let Actions = require("../../src/actions/index");

describe("Testing the actions for getting weather", () => {
    let fetchStub;

    beforeEach(() => {
        fetchStub = sinon.stub(Actions, 'createWeatherRequest');
    });

    afterEach(() => {
        sinon.restore(Actions.createWeatherRequest);
    });

    it("gets weather from the supplied url and triggers the corresponding action", () => {
        fetchStub.returns((function() {
            return {
                then: function(resolve) {
                    resolve("test_response");
                }
            };
        })());

        let fetchWeatherThunk = Actions.default("test_url");

        //see if our stub has been called
        expect(fetchStub.called).to.be.true;

        let dispatchSpy = sinon.spy();

        fetchWeatherThunk(dispatchSpy);

        //Now since we have resolved the request, the dispatchSpy should have been called
        expect(dispatchSpy.called).to.be.true;

        let expectedResponse = {
            type: 'SHOW_WEATHER',
            payload: "test_response"
        };

        //Now check if it was called with the "test_response"
        expect(dispatchSpy.calledWith(expectedResponse)).to.be.true;
    });
});
