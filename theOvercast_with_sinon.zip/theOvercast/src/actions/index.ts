declare const module;
import * as axios from 'axios';
const API_ID= '1fa29c229cb1524ee3f5a8faf192526d';
const WEATHER_URL = `http://api.openweathermap.org/data/2.5/forecast?appid=${API_ID}`;

export default function fetchWeather(city:string) {

  const url = `${WEATHER_URL}&q=${city},us`;
  const request = module.exports.createWeatherRequest(url);

  return function (dispatch) {
    return request.then((response) => {
        dispatch({type: 'SHOW_WEATHER', payload: response})
    });
  };
}

export function createWeatherRequest(url) {
    return axios.get(url);
}
