import * as React from 'react';
import * as ReactDOM from 'react-dom';
import TestReact from './components/testReact.tsx';
import App from './components/app.tsx';
import ComParent from './checkComp/comparent.tsx';
import MasterBoot from './bootstraped/masterBoot.tsx';

ReactDOM.render(<MasterBoot />, document.getElementById('root'));
