import * as $ from 'jquery';

export default (state:any=null, action) =>{
  switch(action.type){
      case 'SHOW_WEATHER':
      let prevState=[];
      if(state!=null){
        prevState= $.extend([], state.weather);
      }
      prevState.push(action.payload.data);
      let updateState=prevState;
      return $.extend([], state, {weather: updateState});
      default:
      return state;
  }
};
