import * as React from 'react';
import Header from './header.tsx';
import NavBars from './navbars.tsx';

interface Props extends React.Props<MasterBoot>{

}

interface State{

}

class MasterBoot extends React.Component<Props, State>{

  public render(){
    return(
      <div className="container">
        <Header />
        <NavBars />
      </div>
    )
  }
}

export default MasterBoot;
