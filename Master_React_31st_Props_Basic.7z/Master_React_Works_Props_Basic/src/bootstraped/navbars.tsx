import * as React from 'react';

interface Props extends React.Props<NavBars>{

}

interface State{

}

export default class NavBars extends React.Component<Props, State>{

  public render(){
    return(<div className="row pad-nav">
      <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        <div className="container-fluid nav-cont">
        <nav className="navbar navbar-default">

        </nav>
        </div>
      </div>      
    </div>
    );
  }

}
