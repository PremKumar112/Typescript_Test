import * as React from 'react';

interface Props extends React.Props<Header>{

}

interface State{

}

class Header extends React.Component<Props, State>{

  constructor(props){
    super(props);
  }

public render(){
  return(<div className="row">
    <header>
      <div className="headrow">
        <div className="col-xs-12 col-sm-12 col-md-3 col-lg-3 pull-left">
          <img src="./img/aricentlogo.jpg" alt="Logo" />
            </div>
      <div className="col-xs-12 col-sm-12 col-md-6 col-lg-6 text-center stl-h1">
		        <h1>Aricent</h1>
	     </div>
			<div className="col-xs-12 col-sm-12 col-md-3 col-lg-3">
        <div className="btn-pad pull-right">
        <a href="#"><span className="glyphicon glyphicon-user">User</span></a>
				<a href="#"><span className="glyphicon glyphicon-shopping-cart">Cart</span></a>
        </div>
      </div>
          </div>
        </header>
      </div>);
  }

}

export default Header;
