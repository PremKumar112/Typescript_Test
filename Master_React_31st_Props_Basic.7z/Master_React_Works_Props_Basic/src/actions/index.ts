import * as axios from 'axios';
const API_ID='1fa29c229cb1524ee3f5a8faf192526d';
const WEATHER_API=`http://api.openweathermap.org/data/2.5/forecast?appid=${API_ID}`;

let fetchWeather=(city:string)=>{
  const url= `${WEATHER_API}&q=${city},us`;
  const request=axios.get(url);

  return (dispatch)=>{
    return request.then((response)=>
      dispatch({type:'SHOW_WEATHER', payload:response})
    );
  }
}
export default fetchWeather;
