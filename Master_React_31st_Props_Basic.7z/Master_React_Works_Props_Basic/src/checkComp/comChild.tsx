import * as React from 'react';

interface Props extends React.Props<ComChild>{
  text?:string;
  name?:string;
  lastName:string;
}

interface State{
  userName:string;
  lastUser:string;
}

export default class ComChild extends React.Component<Props, State>{

  constructor(props){
    super(props);
    this.state={
      userName: props.nameC,
      lastUser: props.lastName
    }
    }

    public render(){
      return(
      <div>
        <h1>The Name of Child is: {this.props.name} {this.state.userName} {this.state.lastUser}</h1>
      </div>
      )
    }
    }
