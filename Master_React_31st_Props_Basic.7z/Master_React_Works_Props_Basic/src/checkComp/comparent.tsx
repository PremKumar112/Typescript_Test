import * as React from 'react';
import ComChild from './comChild';

interface Props extends React.Props<ComParent>{
  nameC?:string;
  name?:string;
  lastName:string;
}

interface State{

}

export default class ComParent extends React.Component<Props, State>{

  public render(){
    console.log(this.props);
    return(<div>
      <ComChild {...this.props} />
    </div>
    )
  }


}
