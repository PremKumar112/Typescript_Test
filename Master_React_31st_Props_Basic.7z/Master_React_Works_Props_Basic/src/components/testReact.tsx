import * as React from 'react';

interface Props extends React.Props<TestReact>{

}
interface State{
  tick?:number
  alps?:boolean
}


export default class TestReact extends React.Component<Props,State>{

    constructor(props){
      super(props);
      this.state={tick:0, alps: true};
      this.changeState=this.changeState.bind(this);
    }

    changeState(){
      let x:number = this.state.tick+1;
      console.log(x);
      if(x<5){
      this.setState({tick: this.state.tick+1});
      }
      else{
        this.setState({alps: !this.state.alps});
      }
    }

    public render(){

      if(this.state.alps==true){
      return(
        <div><h1>Component Has Re-rendered {this.state.tick} times</h1>
        <span className="input-group-btn">
          <button onClick={this.changeState} className="btn btn-secondary">Submit</button>
        </span>
        </div>
      );
      }
      else{
        return(
          <div><h1>Stop Clicking!! DON'T YOU HAVE ANYTHING BETTER TO DO</h1></div>
        );
      }
    }
}
