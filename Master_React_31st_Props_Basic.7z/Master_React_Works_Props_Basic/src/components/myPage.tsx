import * as React from 'react';
import {connect} from 'react-redux';
import { bindActionCreators } from 'redux';
import fetchWeather from '../actions';

interface Props extends React.Props<MyPage>{
  employee?:Array<any>;
  fetchWeather?:(city:string)=>void
}

interface State{
  mySearch:string
}

class MyPage extends React.Component<Props, State>{

  constructor(props){
    super(props);
    this.state={mySearch: ''};
    this.onInputChange=this.onInputChange.bind(this);
    this.onFormSubmit=this.onFormSubmit.bind(this);

  }

  onInputChange(event){
    this.setState({mySearch: event.target.value});
  }

  onFormSubmit(event){
    event.preventDefault();
    let city:string=this.state.mySearch;
    this.props.fetchWeather(city);
    this.setState({mySearch: ''});
  }

  displayWeather(cityWeather, index){
    console.log(cityWeather);
  }

  public render(){
    var listWeather:any;

    if(this.props.employee){
      listWeather=this.props.employee.map(this.displayWeather);
    }

    return(
      <div className="container">
        <h1>Overcast</h1>
        <div className="row">
          <div className="col-xs-12 col-sm-12 col-md-2 col-lg-2"></div>
          <div className="col-xs-12 col-sm-12 col-md-8 col-lg-8">
            <form onSubmit={this.onFormSubmit} className="input-group">
              <input placeholder="Get Week Forecast for your city"
              className="form-control"
              onChange={this.onInputChange}
              value={this.state.mySearch}/>
              <span className="input-group-btn">
                <button className="btn btn-secondary">Submit</button>
              </span>
            </form>
          </div>
          <div className="col-xs-12 col-sm-12 col-md-2 col-lg-2"></div>
        </div>
        <hr />
        <div className="row">
          <table className="table table-bordered bg-warning">
            <thead>
              <tr>
                <th>City</th>
                <th>Temperature</th>
                <th>Pressure</th>
                <th>Humidity</th>
              </tr>
            </thead>
            <tbody>
              {listWeather}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

const mapStatetoProps=(state)=>{
  console.log(state);
  if(state.employees!=null){
  return {
    employee: state.employees.weather
    }
  }
  return {
  employee:[]
  }

}

const mapDispatchToProps=(dispatch)=>{
  return bindActionCreators ({fetchWeather}, dispatch);
}

const MPage = connect(mapStatetoProps, mapDispatchToProps)(MyPage);
export default MPage;
