import * as React from 'react';
export namespace Header {
  export interface Props {
    name:string;
  }

  export interface State {
  }
}

export class Header extends React.Component<Header.Props, Header.State> {
      constructor(props) {
        super(props)
    }
  render() {
    return (
    <div>
    <header>
      <div className="headrow">
        <div className="col-xs-12 col-sm-12 col-md-3 col-lg-3">
          <img className="pad-5-px" width="200" src="assets/images/logo.png" alt="Logo" />
        </div>
        <div className="col-xs-12 col-sm-12 col-md-7 col-lg-7 text-center">
          <h1>Aricent</h1>
        </div>
        <div className="col-xs-12 col-sm-12 col-md-2 col-lg-2">
          <i className="fa fa-user fa-lg pad-t-30px pull-right"></i>
        </div>
      </div>
    </header>
  </div>
    );
  }
}



