import * as React from 'react';
import { mount } from 'enzyme';
import {expect} from 'chai';
import 'mocha';
import jsdomify from 'jsdomify';

import {Header} from './header';
import {App} from '../../containers/App'


describe('Should have Header div', () =>{
    let _page, div

    beforeEach(() => {
        jsdomify.create();
        document.open()
        document.write("<html><body><p>Hello World!</p></body></html>")
        div = document.createElement('div')
        document.body.appendChild(div)
        _page = mount(
                 <Header name="Ashu" />
            ,{ attachTo: div })
        console.log("Document " , document);
   })

    afterEach(() => {
        _page.detach()
        document.body.removeChild(div)
        jsdomify.destroy();
    })


  it.only('Header Prop should exist', function(){
    expect(_page.props().name).to.equal("Ashu");
  });


  it('Header should have children', function(){
    expect(_page.children()).to.exist;
  });

  it('App should contain a Header Component', function(){
    expect(_page.find(Header)).to.have.length(1);
  });

/*
describe('A basic test', () =>{
    it('should pass when everything is OK', () =>{
        expect(true).to.be.true;
    });
*/
}); 
