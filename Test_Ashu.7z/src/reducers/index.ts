import { combineReducers, Reducer } from 'redux';

export interface RootState {
}

export default combineReducers<RootState>({
});
