import * as React from 'react';
import { RouteComponentProps } from 'react-router';
import {Header} from '../../components';
//require('./index.scss');

export namespace App {
  export interface Props extends RouteComponentProps<void> {
  }

  export interface State {
    /* empty */
  }
}

export class App extends React.Component<{}, {}> {

  render() {
    return (
      <div className="container">
        <Header />
      </div>
    );
  }
}
