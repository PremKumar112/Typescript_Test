export default class EmployeeEntity {
  _id: number;
  body: string;
  id: number;
  title: string;
  userId: number;

  constructor() {
    this._id = -1;
    this.body = "";
    this.id = -1;
    this.title = "";
    this.userId = -1;    
  }
}
