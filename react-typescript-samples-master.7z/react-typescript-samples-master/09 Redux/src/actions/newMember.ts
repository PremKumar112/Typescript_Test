const initializeNewMember = () => {
   return {
     type: 'INITIALIZE_NEW_MEMBER'
   }
}

export default initializeNewMember;
