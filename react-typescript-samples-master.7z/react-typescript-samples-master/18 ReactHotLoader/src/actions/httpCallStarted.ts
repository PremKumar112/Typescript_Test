const httpCallStarted = () => {
   return {
     type: 'HTTP_GET_CALL_STARTED'
   }
}

export default httpCallStarted;
