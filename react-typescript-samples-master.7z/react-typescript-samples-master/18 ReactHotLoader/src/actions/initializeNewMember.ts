const initializeNewMember = () => {
   return {
     type: 'MEMBER_INITIALIZE_NEW'
   }
}

export {
    initializeNewMember
};
