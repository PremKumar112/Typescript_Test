
const resetSaveCompleted = () => {
   return {
     type: 'MEMBER_RESET_SAVE_COMPLETED'
   }
}

export {
    resetSaveCompleted
};
