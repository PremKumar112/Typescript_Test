const httpCallCompleted = () => {
   return {
     type: 'HTTP_GET_CALL_COMPLETED'
   }
}

export default httpCallCompleted;
