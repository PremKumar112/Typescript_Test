export default class RepoEntity {
  id: number;
  name: string;

  constructor(){
    this.id = -1;
    this.name = "";
  }
};
