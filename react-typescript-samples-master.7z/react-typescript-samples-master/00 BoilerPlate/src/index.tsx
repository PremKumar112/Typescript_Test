var App = console.log('Hello from tsx');

export default App;
